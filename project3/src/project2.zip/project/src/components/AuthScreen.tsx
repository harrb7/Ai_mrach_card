import { useState } from 'react';
import { Lock, MessageCircle, Phone } from 'lucide-react';

interface AuthScreenProps {
  onAuthenticate: () => void;
}

function AuthScreen({ onAuthenticate }: AuthScreenProps) {
  const [licenseKey, setLicenseKey] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const KeyAuth = (window as any).KeyAuth;

      if (!KeyAuth) {
        setError('KeyAuth library not loaded. Please refresh the page.');
        setIsLoading(false);
        return;
      }

      const KeyAuthApp = new KeyAuth({
        name: "matchgen",
        ownerid: "FYkAfUvtKZ",
        version: "1.0",
      });

      await KeyAuthApp.init();

      const response = await KeyAuthApp.license(licenseKey);

      if (KeyAuthApp.success) {
        onAuthenticate();
      } else {
        setError('Invalid license key. Please try again or contact support.');
      }
    } catch (err) {
      setError('Failed to validate license key. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl shadow-2xl p-8 border border-slate-700 mb-8">
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mb-4">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">MatchGen</h1>
            <p className="text-slate-400 text-center">Enter your license key</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label htmlFor="license" className="block text-sm font-medium text-slate-300 mb-2">
                License Key
              </label>
              <input
                type="text"
                id="license"
                value={licenseKey}
                onChange={(e) => setLicenseKey(e.target.value)}
                className="w-full px-4 py-3 bg-slate-900/50 border border-slate-600 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                placeholder="Paste your license key"
                required
                disabled={isLoading}
              />
            </div>

            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/50 rounded-lg">
                <p className="text-sm text-red-400">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading || !licenseKey.trim()}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 disabled:cursor-not-allowed text-white font-semibold rounded-lg transition duration-200 flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Validating...
                </>
              ) : (
                <>
                  <Lock className="w-5 h-5" />
                  Unlock
                </>
              )}
            </button>
          </form>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-lg rounded-2xl shadow-2xl p-6 border border-slate-700">
          <h2 className="text-white font-semibold text-center mb-4">Need a license key?</h2>
          <div className="space-y-3">
            <a
              href="https://t.me/h1rbb"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-lg transition duration-200 flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-5 h-5" />
              Contact on Telegram
            </a>

            <a
              href="https://wa.me/201013390833"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 bg-green-500 hover:bg-green-600 text-white font-medium rounded-lg transition duration-200 flex items-center justify-center gap-2"
            >
              <Phone className="w-5 h-5" />
              Contact on WhatsApp
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AuthScreen;
