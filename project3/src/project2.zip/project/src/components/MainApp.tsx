import { CheckCircle } from 'lucide-react';

function MainApp() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="text-center">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-green-500 rounded-full mb-6">
          <CheckCircle className="w-12 h-12 text-white" />
        </div>
        <h1 className="text-4xl font-bold text-white mb-4">Welcome to MatchGen!</h1>
        <p className="text-xl text-slate-300 mb-8">Your license has been verified successfully.</p>
        <div className="bg-slate-800/50 backdrop-blur-lg rounded-xl p-8 border border-slate-700 max-w-2xl mx-auto">
          <p className="text-slate-400">
            You now have full access to all features. Start building amazing things!
          </p>
        </div>
      </div>
    </div>
  );
}

export default MainApp;
