import { useState } from 'react';
import AuthScreen from './components/AuthScreen';
import MainApp from './components/MainApp';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {!isAuthenticated ? (
        <AuthScreen onAuthenticate={() => setIsAuthenticated(true)} />
      ) : (
        <MainApp />
      )}
    </div>
  );
}

export default App;
